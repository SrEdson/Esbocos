#Contador de Caracteres
#Objetivo: contar caracteres numa varialvel string
#Programador: Edson E. francisco
#09/02/2022

a = "   Contando tambem os espacos   "

print("essa string tem:",len(a), "caracteres")